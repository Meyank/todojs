var asmt={
   assmt:[],
   display:function(){
     for(var i =0;i<this.assmt.length;i++)
    {if(this.assmt[i].completed===true){
           console.log('(x)', this.assmt[i].assmtt);}
     else
      {  
     console.log('()',this.assmt[i].assmtt);
   }}},
     add:function(newText){
    this.assmt.push({assmtt:newText,completed:false}); 
    this.display();        
},    
    edit:function(position,newValue){
        this.assmt[position].assmtt=newValue;
        this.display();
        
    },
    
    delete:function(position){
        
      this.assmt.splice(position,1);
        this.display(); 
        
    },
    

    toggle:function(position){
     this.assmt[position].completed=!this.assmt[position].completed;
        this.display();
},
   
    toggleall:function(){
       var completed=0;
     var  totallength=this.assmt.length;
        for(var i=0;i<totallength ;i++){
            if(this.assmt[i].completed==true)
            completed++;
                   
        }
        
        
        if(totallength==completed){
        for(var i=0;i<this.assmt.length;i++){
           this.assmt[i].completed=false;
           
        }
          this.display(); 
        }
        else{
            for( i=0;i<this.assmt.length;i++){
            this.assmt[i].completed=true;
           
        }
         this.display();
    }
    
    } 
  
    
    
    
};

var DisplayAssignments=document.getElementById("DisplayAssignments");
var ToggleAssignments=document.getElementById("ToggleAssignments");

DisplayAssignments.addEventListener('click',function(){ asmt.display();}) ;
ToggleAssignments.addEventListener('click',function(){ asmt.toggleall();}) ;

var handler={
   display:function(){
     asmt.display();
 },
    add:function(){
      var addAssignments=document.getElementById("inputTextbox"); 
        asmt.add(addAssignments.value);
        addAssignments.value=" ";
    },
    edit:function(){
     var position=document.getElementById("position");
     var newText=document.getElementById("newinputTextbox");
        asmt.edit(position.value,newText.value);
    },   
    toggle:function(){
      var position=document.getElementById("positiontoggle");
       asmt.toggle(position.valueAsNumber);
},
    delete:function(){
       var position=document.getElementById("positionDelete");
       asmt.delete(position.valueAsNumber); 
    },
    toggleall:function(){
        
        asmt.toggleall();
    }
    

};

var view={
    display:function(){
        
        var ul = document.querySelector('ul');
        ul.innerHTML='';
        console.log(ul);
        var completed='';
        for(var i=0;i<asmt.assmt.length;i++){
            
          var status = asmt.assmt[i].completed;
            if(status==true){
              completed= '(x)' + asmt.assmt[i].assmtt;  
            }
            else{
                completed= '()' + asmt.assmt[i].assmtt;   
            }
            var li=    document.createElement('li');
            
            li.textContent=completed;
            ul.appendChild(li);
            
            console.log(li);
            
        }
        
        
    }
    
    
    
};






                                   
